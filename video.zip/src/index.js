import React from 'react';
import ReactDOM from 'react-dom';
import App from './Components/app';


ReactDOM.render(
	<App />, document.querySelector('#root')
);