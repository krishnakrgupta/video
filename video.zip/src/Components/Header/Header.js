import React from 'react';
import logo from './logo.png';
const Header = () => {

    return <div className="ui grid">
                <div className="ui row">
                    <div className="five wide column"><img alt="logo" src={logo} width="100" height="50"  /></div>
                    <div className="eleven wide column">
                        <div className="ui three item menu">
                            <a className="item active" href="">Home</a>
                            <a className="item" href="">About Us</a>
                            <a className="item" href=""> Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>;
};

export default Header;