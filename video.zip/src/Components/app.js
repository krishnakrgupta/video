import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Header from './Header/Header';
import SearchBar from './SearchBar';
import youtube from '../apis/youtube';
import VideoList from './VideoList';
import VideoDetail from './VideoDetail';
import ContactUs from './ContactUs/ContactUs';

class App extends React.Component {

    state = { videos: [], selectedVideo: null };

    /*
    @React to load default search result on keyword 'building'
    */
    componentDidMount(){
        this.onTermSubmit('building');
    }

    /*
    @React to show the search result list
    */
    onTermSubmit = async term => {
        const response = await youtube.get('/search',{
            params:{
                q:term
            }
        });
        //console.log(response.data.items);
        this.setState({
            videos: response.data.items,
            selectedVideo: response.data.items[0]

        });
    };

    /*
    @React to show the selected video item
    */
    onVideoSelect = (video) =>{
        //console.log('from the video', video);
        this.setState({selectedVideo: video });
    };

    render(){
        return (
            <div>
                <div className="ui container">
                        <Header />
                        <Router>
                        <Switch>
                            <Route exact path='/contact' component={ContactUs} />
                        </Switch>
                        </Router>
                </div>
                <div className="ui container" style={{marginTop:'10px'}}>
                    <SearchBar onFormSubmit = { this.onTermSubmit } />
                    <div className="ui grid">
                        <div className="ui row">
                            <div className="eleven wide column">
                                <VideoDetail video={ this.state.selectedVideo }/> 
                            </div>
                            <div className="five wide column">
                            <VideoList onVideoSelect={this.onVideoSelect} videos = {this.state.videos}/>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="ui container"><ContactUs /></div>
            </div>
        );
    }
} 

export default App;