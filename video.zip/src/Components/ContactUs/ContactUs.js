import React from 'react';
const ContactUs = () => {

    return <div className="ui grid">
            <div className="ui row">
                <div className="twelve wide column">
                Best building demolition compilation of 2017 by Fail City. Buildings demolish Best building demolition compilation of 2017 by Fail City. Buildings demolish Best building demolition compilation of 2017 by Fail City. Buildings demolish Best building demolition compilation of 2017 by Fail City. Buildings demolish
                </div>
            </div>
        </div>;
};

export default ContactUs;