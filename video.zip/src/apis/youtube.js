import axios from 'axios';

const KEY='AIzaSyBhJbmlV-20C2a4MnTi7v5_zuvAr0v28e4';

export default axios.create({
    baseURL: 'https://www.googleapis.com/youtube/v3',
    params: {
        part: 'snippet',
        maxresults: 5,
        key: KEY
    }
});